import React from 'react'

function WhishList() {
  return (
    <div>
      WhishList
    </div>
  )
}

export default WhishList
