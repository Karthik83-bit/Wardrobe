import React from 'react'

function NoPath() {
  return (
    <div>
      NO routes available
    </div>
  )
}

export default NoPath
